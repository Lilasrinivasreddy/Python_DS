def addition(m1,m2):
    return m1+m2

def subtraction(m1,m2):
    return m1-m2
    
def multiplication(m1,m2):
    return m1*m2

